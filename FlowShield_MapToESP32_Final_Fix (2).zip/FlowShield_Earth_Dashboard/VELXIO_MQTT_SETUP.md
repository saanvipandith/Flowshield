# FlowShield + Velxio ESP32 integration

This project is the uploaded Velxio project with the original sensor/pin logic preserved and MQTT added.

## MQTT
Broker: `broker.hivemq.com:1883`

Topics:
- `flowshield/node1/telemetry` — ESP32 -> FlowShield dashboard
- `flowshield/node1/command/location` — dashboard -> ESP32
- `flowshield/node1/status` — ESP32 online status

## Velxio Wi-Fi
The sketch uses `Velxio-GUEST`. Velxio documents that simulated ESP32 boards can reach the internet and that MQTT works through the built-in network.

## Map -> ESP32
The dashboard publishes the selected map coordinate as plain text:

`latitude,longitude`

Example:

`12.971600,77.594600`

The ESP32 receives it, stores it as the active map location, and echoes it in the next telemetry message.

## Sensor interpretation
The uploaded hardware does not have a dedicated rainfall or terrain sensor.

For the demo:
- `inflow_adc` is converted to `rainfall_mm_h` with a 0-4095 ADC -> 0-250 mm/h calibration.
- `gps_altitude_m` is provided as a GPS elevation/terrain proxy when the GPS reports altitude.
- `upstream_cm` is converted to `water_level_cm` using a 30 cm assumed sensor mounting height.

Change those constants in `sketch.ino` if your physical calibration is different.

## Public broker
This uses a public MQTT broker for demonstration. Do not publish sensitive information. A unique private broker/topic should be used for a production deployment.
