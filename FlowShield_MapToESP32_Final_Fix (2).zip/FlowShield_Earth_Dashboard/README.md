# FlowShield — Earth Theme Flood Early Warning Dashboard

A runnable prototype for the supplied FlowShield problem statement.

## Included features
- Earth-themed flood dashboard with interactive OpenStreetMap map.
- Click any map point to select a sensor location.
- Local Node bridge stores the selected coordinate.
- Wokwi ESP32 polls the selected coordinate and posts rainfall, elevation and drainage readings back to the dashboard.
- Manual rainfall / drainage / initial water / terrain / population controls.
- Connected 7×7 region grid with water accumulation, movement, drainage and terrain effects.
- Safe / Warning / Critical classification.
- Time-based flood progression with an interactive 0–120 minute slider.
- Estimated affected population.
- Estimated time to critical conditions.
- Nearest safe region, distance and simple grid-route visualization.
- AI-style automated citizen alert generation (template-based in this offline prototype).
- Light / Monsoon / Extreme scenario comparison.
- Demo ESP32 button for presentations when Wokwi is not running.

## Open the website without localhost
You can now extract the ZIP and **double-click `index.html`**. The Earth/Street map loads directly in the browser and the complete flood simulation, time slider, risk grid, population estimate, safe-region calculation, route panel and citizen message work in **browser-only demo mode**. Internet access is required for the OpenStreetMap tiles.

The Node server is optional and is only needed when you want the live Wokwi ESP32 bridge.

## Optional live Wokwi bridge
Requires Node.js 18+.

```bash
npm start
```
Then open the dashboard from the server. This enables the ESP32/Wokwi coordinate and sensor-reading bridge.

## Wokwi integration
1. Start the dashboard with `npm start`.
2. Open the `wokwi/` folder in Wokwi or create a new ESP32 project.
3. Use `sketch.ino` and `diagram.json`.
4. The sketch uses `http://host.wokwi.internal:3000` so the Wokwi ESP32 can reach the local Node bridge.
5. Start the Wokwi simulation.
6. In FlowShield, click a map point. The ESP32 polls that coordinate.
7. Turn the three potentiometers:
   - Rain = rainfall intensity, 0–250 mm/h
   - Terrain = elevation, 0–1500 m
   - Drain = drainage capacity, 5–120 mm/h
8. The dashboard updates the sensor card. Press **Run simulation** to model the flood.

## Notes
The flood model is a demonstration model rather than a calibrated hydrological model. OpenStreetMap tiles require internet access. The citizen message is generated locally from the simulation state and should not be treated as an official emergency alert.
