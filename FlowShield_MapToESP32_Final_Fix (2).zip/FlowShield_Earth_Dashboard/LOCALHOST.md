# FlowShield — local website

This version keeps the dashboard behavior unchanged except for the Scenario Comparison fix.

## Run on localhost

Requirements: Node.js installed.

From this folder run:

```bash
node server.js
```

Then open:

`http://localhost:3000`

Do not open `index.html` directly; use the local server.

The website still uses MQTT over secure WebSockets for the Velxio ESP32 connection. Localhost is only used to host the FlowShield website.
